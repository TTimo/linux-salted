#atom-sourcetrail

The Atom plugin is hosted at Github.

Link to the repository: [atom-sourcetrail](https://github.com/CoatiSoftware/atom-sourcetrail).
