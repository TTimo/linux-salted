#idea-sourcetrail

The CLion/IntelliJ plugin is hosted at Github.

Link to the repository: [idea-sourcetrail](https://github.com/CoatiSoftware/idea-sourcetrail).
